package com.soundless.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF243447)
private val Teal = Color(0xFF39877D)
private val Pale = Color(0xFFF3F6F5)
private val Muted = Color(0xFF687782)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("soundless_data", MODE_PRIVATE)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Teal,
                    onPrimary = Color.White,
                    background = Pale,
                    surface = Color.White,
                    onSurface = Ink
                )
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    SoundlessApp(prefs)
                }
            }
        }
    }
}

private data class DayData(
    val tasks: List<Boolean> = List(4) { false },
    val anticipation: Int = 0,
    val checking: Int = 0,
    val sleepWorry: Int = 0,
    val latency: String = "",
    val awakenings: String = "",
    val note: String = ""
)

private val taskNames = listOf(
    "۱۰ دقیقه تمرین توجه",
    "۱۰ تا ۲۰ دقیقه فعالیت با صدای معمول محیط",
    "روال آرام‌سازی پیش از خواب",
    "پس از شنیدن صدا، بررسی را رها کردم"
)

@Composable
private fun SoundlessApp(prefs: android.content.SharedPreferences) {
    var selectedDay by remember { mutableIntStateOf(1) }
    var refresh by remember { mutableIntStateOf(0) }

    fun load(day: Int): DayData {
        val raw = prefs.getString("day_$day", null) ?: return DayData()
        return try {
            val o = JSONObject(raw)
            val arr = o.optJSONArray("tasks")
            val tasks = List(4) { i -> arr?.optBoolean(i, false) ?: false }
            DayData(
                tasks = tasks,
                anticipation = o.optInt("anticipation", 0),
                checking = o.optInt("checking", 0),
                sleepWorry = o.optInt("sleepWorry", 0),
                latency = o.optString("latency", ""),
                awakenings = o.optString("awakenings", ""),
                note = o.optString("note", "")
            )
        } catch (_: Exception) { DayData() }
    }

    fun save(day: Int, d: DayData) {
        val o = JSONObject()
        val a = org.json.JSONArray()
        d.tasks.forEach { a.put(it) }
        o.put("tasks", a)
        o.put("anticipation", d.anticipation)
        o.put("checking", d.checking)
        o.put("sleepWorry", d.sleepWorry)
        o.put("latency", d.latency)
        o.put("awakenings", d.awakenings)
        o.put("note", d.note)
        prefs.edit().putString("day_$day", o.toString()).apply()
        refresh++
    }

    val data = remember(selectedDay, refresh) { load(selectedDay) }
    val completed = data.tasks.count { it }
    val weeklyStart = ((selectedDay - 1) / 7) * 7 + 1
    val weeklyEnd = minOf(weeklyStart + 6, 28)
    val weekName = when (selectedDay) {
        in 1..7 -> "هفته اول · شکستن عادت بررسی صدا"
        in 8..14 -> "هفته دوم · کاهش انتظار صدا"
        in 15..21 -> "هفته سوم · بازآموزی هنگام خواب"
        else -> "هفته چهارم · تثبیت مهارت‌ها"
    }

    Column(
        modifier = Modifier.fillMaxSize().background(Pale).padding(horizontal = 16.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 12.dp)) {
            Text("بازآموزی ذهن", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text("پروژه ۲۸ روزه کاهش گوش‌به‌زنگی و بهبود خواب", color = Muted, fontSize = 13.sp)
        }

        Card(colors = CardDefaults.cardColors(containerColor = Ink), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                Text("روز $selectedDay از ۲۸", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(weekName, color = Color(0xFFD6E6E2), fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { selectedDay / 28f },
                    modifier = Modifier.fillMaxWidth().height(7.dp),
                    color = Color(0xFF8DD2C4),
                    trackColor = Color(0xFF526477)
                )
                Spacer(Modifier.height(6.dp))
                Text("انجام تمرین‌های امروز: $completed از ۴", color = Color.White, fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(14.dp))
        Text("انتخاب روز", fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            items((1..28).toList()) { day ->
                FilterChip(
                    selected = selectedDay == day,
                    onClick = { selectedDay = day },
                    label = { Text(day.toString()) }
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            SectionTitle("چک‌لیست امروز")
            taskNames.forEachIndexed { index, name ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 3.dp)
                        .background(Color.White, RoundedCornerShape(12.dp)).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = data.tasks[index],
                        onCheckedChange = { checked ->
                            save(selectedDay, data.copy(tasks = data.tasks.toMutableList().also { it[index] = checked }))
                        }
                    )
                    Text(name, color = Ink, fontSize = 13.sp)
                }
            }

            Spacer(Modifier.height(16.dp))
            SectionTitle("ثبت وضعیت ذهن · از ۰ تا ۱۰")
            Text("۰ یعنی اصلاً · ۱۰ یعنی بسیار زیاد", color = Muted, fontSize = 11.sp)
            ScoreSlider("انتظار برای شنیدن صدا", data.anticipation) {
                save(selectedDay, data.copy(anticipation = it))
            }
            ScoreSlider("بررسی و دنبال‌کردن صدا", data.checking) {
                save(selectedDay, data.copy(checking = it))
            }
            ScoreSlider("نگرانی از خوابیدن با وجود صدا", data.sleepWorry) {
                save(selectedDay, data.copy(sleepWorry = it))
            }

            Spacer(Modifier.height(12.dp))
            SectionTitle("ثبت خواب")
            OutlinedTextField(
                value = data.latency,
                onValueChange = { save(selectedDay, data.copy(latency = it.filter(Char::isDigit).take(3))) },
                label = { Text("زمان تقریبی خواب‌رفتن (دقیقه)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = data.awakenings,
                onValueChange = { save(selectedDay, data.copy(awakenings = it.filter(Char::isDigit).take(2))) },
                label = { Text("تعداد بیداری‌های شبانه") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(Modifier.height(12.dp))
            SectionTitle("یادداشت کوتاه")
            OutlinedTextField(
                value = data.note,
                onValueChange = { save(selectedDay, data.copy(note = it.take(500))) },
                placeholder = { Text("امروز چه چیزی کمک کرد؟ چه چیزی دشوار بود؟") },
                modifier = Modifier.fillMaxWidth().heightIn(min = 90.dp),
                maxLines = 4
            )

            Spacer(Modifier.height(18.dp))
            SectionTitle("مرور هفتگی")
            val weekly = (weeklyStart..weeklyEnd).map { load(it) }
            val avgA = weekly.filter { it.anticipation > 0 }.map { it.anticipation }.averageOrNull()
            val avgC = weekly.filter { it.checking > 0 }.map { it.checking }.averageOrNull()
            val avgS = weekly.filter { it.sleepWorry > 0 }.map { it.sleepWorry }.averageOrNull()
            Text("میانگین هفته جاری (روزهای ثبت‌شده)", color = Muted, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricCard("انتظار صدا", avgA, Modifier.weight(1f))
                MetricCard("بررسی صدا", avgC, Modifier.weight(1f))
                MetricCard("نگرانی خواب", avgS, Modifier.weight(1f))
            }
            Spacer(Modifier.height(16.dp))
            Text(
                "یادآوری: هدف حذف صدا نیست؛ هدف این است که صدا را بشنوی، بدون اینکه مجبور باشی آن را بررسی کنی. با صدای معمول و قابل‌تحمل تمرین کن؛ خودت را در معرض صدای بلند یا آزاردهنده قرار نده.",
                color = Muted, fontSize = 12.sp, lineHeight = 19.sp
            )
            Spacer(Modifier.height(28.dp))
        }
    }
}

private fun List<Double>.averageOrNull(): Double? = if (isEmpty()) null else average()

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(bottom = 8.dp))
}

@Composable
private fun ScoreSlider(title: String, score: Int, onChange: (Int) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(title, color = Ink, fontSize = 13.sp)
                Text("$score / ۱۰", color = Teal, fontWeight = FontWeight.Bold)
            }
            Slider(value = score.toFloat(), onValueChange = { onChange(it.toInt()) }, valueRange = 0f..10f, steps = 9)
        }
    }
}

@Composable
private fun MetricCard(title: String, value: Double?, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontSize = 10.sp, color = Muted)
            Text(value?.let { String.format(Locale.US, "%.1f", it) } ?: "—", fontSize = 19.sp, color = Teal, fontWeight = FontWeight.Bold)
        }
    }
}
